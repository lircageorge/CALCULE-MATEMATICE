package adunari;

import java.util.Scanner;

public class Calcule {

	public static void main(String[] args) {

		// exemplul 1 de adunare - exemplu 1 cu variabile declarate
		int number1 = 5;
		int number2 = 8;
		int sum = number1 + number2;
		System.out.println(sum);

		// exemplul 2 cu variabile declarate
		int number3 = 21;
		int number4 = 44;
		System.out.println(number3 + number4);

		// alte exemple
		// diferenta a doua numere de mai sus
		int diferenta = number1 - number2;
		System.out.println(diferenta);
		// produsul a doua numere de mai sus
		int produs = number1 * number2;
		System.out.println(produs);
		// raportul a doua numare de mai sus
		int raport = number2 / number1;
		System.out.println(raport);

		// suma a doua numere folosind un calculator si doua numere introduse de
		// catre utilizator
		// pentru a face asta avem nevoie sa initializam scannerul pentru a
		// putea lua valorile de la utilizatori
		Scanner inserare = new Scanner(System.in);
		// avem nevoie sa ne declaram 3 numere: primul numar, al doilea numar
		// precum si rezultatul: suma
		int fnum, snum, fsum, fprod;
		// informam utilizatorul ca trebuie sa introduca primul numar
		System.out.println("Introduceti primul numar: ");
		// atribuim valoarea introdusa de catre utilizator la primul numar
		// declarat de catre noi: fnum
		fnum = inserare.nextInt();
		// informam utilizatorul ca trebuie sa introduca al doilea numar
		System.out.println("Introduceti al doilea numar: ");
		// atribuim valoarea introdusa de catre utilizator la al doilea numar
		// declarat de catre noi: snum
		snum = inserare.nextInt();
		// acum ca stim fnum si snum putem sa declaram si operatia de adunare
		fsum = fnum + snum;
		fprod = fnum * snum;
		// rezultatul operatiei
		System.out.println(fsum);
		System.out.println(fprod);

		// acelasi calculator de mai sus dar folosim double in loc de int (sa
		// putem folosi si numere cu virgula)
		float a, b, sumab;
		System.out.println("Introduceti numarul a: ");
		a = inserare.nextFloat();
		System.out.println("Introduceti numarul b: ");
		b = inserare.nextFloat();
		sumab = a + b;
		System.out.println(sumab);

	}

}
